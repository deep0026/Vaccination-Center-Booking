package com.Area;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AreaApplicationTests {

	@Test
	void contextLoads() {
	}

}
